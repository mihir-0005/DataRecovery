This is a recovery software
The bat file will automatically run the necessary commands and store your recovered files to the 'recovered' folder
If you wish to edit the disk/drive to be scanned open the 'Recovery.py' with your text editor and make the necessary changes  